from compare import expect
from support_code.module_rest import *
from jsondiff import diff

@given(u'I have connection to "{host}"')
def step_impl(context, host):
  context.host=host

@when(u'I compare result')
def step_impl(context):
    #context.api_test = perform_get_request(context.host)
    context.result= perform_request(context.method,context.host)
    context.text=json.loads(context.text)
    # Alternative validation using diff
        # a=diff(context.text,context.api_test)
         # expect(a).to_equal({})
    expect(context.text).to_equal(context.api_test)

@when(u'I "{method}"')
def step_impl(context,method):
    context.method=method

@then(u'I receive status code {code}')
def step_impl(context,code):
    expect(str(context.api_test.status_code)).to_equal(code)



